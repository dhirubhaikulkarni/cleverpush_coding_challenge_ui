import { createSlice } from '@reduxjs/toolkit';

let Data = [
  {
    "id": 1,
    "status": 1,
    "Task": "Task 1",
    "Assigned To": 1,
    "AssignName": "DK",
    "Priority": 1,
    "PriorityType": "Low",
    "Description": "",
  },
  {
    "id": 2,
    "status": 5,
    "Task": "Task 2",
    "Assigned To": 2,
    "AssignName": "MK",
    "Priority": 3,
    "PriorityType": "High",
    "Description": "",
  },
  {
    "id": 3,
    "status": 4,
    "Task": "Task 3",
    "Assigned To": 2,
    "AssignName": "SK",
    "Priority": 2,
    "PriorityType": "Medium",
    "Description": "",
  },
  {
    "id": 4,
    "status": 2,
    "Task": "Task 4",
    "Assigned To": 3,
    "AssignName": "DDK",
    "Priority": 3,
    "PriorityType": "High",
    "Description": "",
  },
  {
    "id": 5,
    "status": 3,
    "Task": "Task 5",
    "Assigned To": 4,
    "AssignName": "SDK",
    "Priority": 2,
    "PriorityType": "Medium",
    "Description": "",
  },
  {
    "id": 6,
    "status": 3,
    "Task": "Task 6",
    "Assigned To": 5,
    "AssignName": "SK",
    "Priority": 1,
    "PriorityType": "Low",
    "Description": "",
  }
]

let Priority = [
  {

    "Priority": 1,
    "PriorityType": "Low",
  },
  {

    "Priority": 2,
    "PriorityType": "Medium",
  },
  {

    "Priority": 3,
    "PriorityType": "High",
  },

]
let Status = [
  {
    "id": 1,
    "status": "Yet To Start",
    "color": "#89afe7",
  },
  {
    "id": 2,
    "status": "Pending",
    "color": "#7dc6a4",
  },
  {
    "id": 3,
    "status": "Successfully Resolved",
    "color": "#e7d8a9",
  },
  {
    "id": 4,
    "status": "Ready For Test",
    "color": "#e99cc2",
  },
  {
    "id": 5,
    "status": "Test Success",
    "color": "#90e7c2",
  },
  {
    "id": 6,
    "status": "Ready For Deployment",
    "color": "#e4a4aa",
  }


]

const initialState = {
  data: Data,
  status: Status,
  proprity: Priority

};

const taskmanagementSlice = createSlice({
  name: 'task',
  initialState,
  reducers: {

  }
});

export const {

} = taskmanagementSlice.actions;

export default taskmanagementSlice.reducer;

