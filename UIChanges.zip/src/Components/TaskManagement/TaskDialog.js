import React, {
    forwardRef,
    useRef,
    useImperativeHandle,
    useEffect,
} from "react";
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import FormControl from "@mui/material/FormControl";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import InputLabel from '@mui/material/InputLabel';
import Icon from '@mui/material/Icon';
import IconButton from '@mui/material/IconButton';
import { useForm, Controller } from 'react-hook-form';
import { TextField } from '@mui/material';
import Grid from '@mui/material/Grid';
import { useDispatch, useSelector } from "react-redux";


const TaskDialog = forwardRef((props, ref) => {
    const [open, setOpen] = React.useState(false);
    const [data, setData] = React.useState([]);
    const Status = useSelector((state) => state.task.status);
    const Priority = useSelector((state) => state.task.proprity);
    const { control, setValue, formState, handleSubmit, reset, trigger, setError } = useForm({
        mode: 'onChange',
    });
    const handleClickOpen1 = () => {
        setOpen(true);
    };

    const handleClose = () => {

        setOpen(false);
    };
    const formRef = useRef(null);
    useImperativeHandle(ref, () => ({
        handleClickOpen(Data) {
            debugger;
            setData(Data)
            setTaskData(Data)
            handleClickOpen1();
        },
    }));

    const [statusValue, setStatusValue] = React.useState('');
    const handleStatusChange = (event) => {
        setStatusValue(event.target.value)
    }
    const [priorityValue, setPriorityValue] = React.useState('');
    const handlePriorityChange = (event) => {
        setPriorityValue(event.target.value)
    }

    const setTaskData = (data) => {
        if (Object.keys(data).length !== 0) {
            setValue("task", data.Task)
            setValue("description", data.Description)
            setStatusValue(data.status)
            setPriorityValue(data.Priority)
        } else {
            setValue("task", "")
            setValue("description", "")
            setStatusValue("")
            setPriorityValue("")
        }
    }
    function onSubmit(model) {
        debugger;


    }


    return (
        <Dialog
            fullWidth={true}
            maxWidth='xs'
            open={open}
            onClose={handleClose}
            aria-labelledby="responsive-dialog-title"
        >

            <DialogTitle id="responsive-dialog-title">{'Add Task'}</DialogTitle>
            <DialogContent dividers>
                <form
                    ref={formRef}
                    autoComplete="off"
                    onSubmit={handleSubmit(onSubmit)}
                >

                    <Grid container spacing={2}>
                        <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                            <Controller
                                type="text"
                                name="task"
                                control={control}
                                render={({ field }) => (
                                    <TextField
                                        {...field}
                                        label="Task"
                                        type="text"
                                        variant="outlined"
                                    />
                                )}
                            />
                        </Grid>
                        <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                            <Controller
                                type="text"
                                name="description"

                                control={control}
                                fullWidth
                                render={({ field }) => (
                                    <TextField
                                        {...field}
                                        label="Task Description"
                                        type="text"
                                        variant="outlined"
                                    />
                                )}
                            />
                        </Grid>
                        <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                            <FormControl className="mt-8 w-full" >
                                <InputLabel id="demo-simple-select-label">{"Status"}</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    value={statusValue}
                                    color="action"
                                    label={"Status"}
                                    onChange={handleStatusChange}
                                    inputProps={{ 'aria-label': 'Without label' }}
                                >

                                    {Status.map((element) => (
                                        <MenuItem key={element.id} value={element.id}>{element.status}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                            <FormControl className="mt-8 w-full" >
                                <InputLabel id="demo-simple-select-label">{"Status"}</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    value={priorityValue}
                                    color="action"
                                    label={"Priority"}
                                    onChange={handlePriorityChange}
                                    inputProps={{ 'aria-label': 'Without label' }}
                                >

                                    {Priority.map((element) => (
                                        <MenuItem key={element.Priority} value={element.Priority}>{element.PriorityType}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} lg={12} xl={12} style={{ marginTop: '16px' }}>
                        <Button type="submit" color="primary" autoFocus variant="contained" style={{ marginRight: '8px' }}>
                            {"SAVE"}
                        </Button>
                        <Button autoFocus onClick={handleClose} color="primary" variant="contained">
                            {"CANCEL"}
                        </Button>
                    </Grid>

                </form>
            </DialogContent>

        </Dialog>

    );
});

export default TaskDialog;
